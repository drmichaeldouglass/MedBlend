__project__ = "platipy"
__version__ = "0.7.1"
__keywords__ = [
    "medical imaging",
    "visualisation",
    "registration",
    "radiotherapy",
    "image analysis",
]
__author__ = "Phillip Chlap & Robert Finnegan"
__author_email__ = "phillip.chlap@unsw.edu.au"
__url__ = "https://pyplati.github.io/platipy/"
__platforms__ = "ALL"
