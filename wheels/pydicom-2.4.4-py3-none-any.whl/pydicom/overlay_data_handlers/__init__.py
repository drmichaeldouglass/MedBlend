
import sys

import pydicom.overlays.numpy_handler as _np_handler

globals()['numpy_handler'] = _np_handler
